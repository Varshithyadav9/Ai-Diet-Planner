function HabitsPage() {
  return (
    <div className="container">
      <div className="card">
        <h1>Habits & Constraints</h1>

        <label>Workout Days Per Week</label>
        <select>
          <option>3 Days</option>
          <option>4 Days</option>
          <option>5 Days</option>
          <option>6 Days</option>
        </select>

        <label>Sleep Hours</label>
        <select>
          <option>5 Hours</option>
          <option>6 Hours</option>
          <option>7 Hours</option>
          <option>8 Hours</option>
        </select>

        <label>Budget</label>
        <select>
          <option>₹2000</option>
          <option>₹3000</option>
          <option>₹5000</option>
          <option>₹7000+</option>
        </select>
      </div>
    </div>
  );
}

export default HabitsPage;