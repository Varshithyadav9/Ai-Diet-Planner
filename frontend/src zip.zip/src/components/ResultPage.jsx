function ResultPage() {
  const prompt = `
You are a professional Indian dietician and fitness coach.

Create a personalized Indian diet and workout plan.

Include:
1. Calories
2. Protein, carbs and fats
3. Breakfast
4. Lunch
5. Snacks
6. Dinner
7. Workout split
8. Exercises with sets and reps
9. Cardio
10. Sleep recommendations

Present in table format.
`;

  function copyPrompt() {
    navigator.clipboard.writeText(prompt);
    alert("Prompt copied!");
  }

  return (
    <div className="container">
      <div className="card">
        <h1>🤖 AI Generated Prompt</h1>

        <textarea
          rows="15"
          value={prompt}
          readOnly
          style={{
            width: "100%",
            padding: "15px",
            borderRadius: "10px"
          }}
        />

        <br /><br />

        <button onClick={copyPrompt}>
          Copy Prompt
        </button>
      </div>
    </div>
  );
}

export default ResultPage;