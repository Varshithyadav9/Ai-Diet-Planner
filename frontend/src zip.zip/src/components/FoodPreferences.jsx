function FoodPreferences() {
  return (
    <div className="container">
      <div className="card">
        <h1>Food Preferences</h1>

        <label>Diet Type</label>
        <select>
          <option>Vegetarian</option>
          <option>Eggetarian</option>
          <option>Non Vegetarian</option>
        </select>

        <label>Protein Source</label>
        <select>
          <option>Chicken</option>
          <option>Eggs</option>
          <option>Fish</option>
          <option>Paneer</option>
          <option>Soya Chunks</option>
        </select>

        <label>Carb Source</label>
        <select>
          <option>Rice</option>
          <option>Roti</option>
          <option>Oats</option>
          <option>Sweet Potato</option>
        </select>

        <label>Favorite Fruit</label>
        <select>
          <option>Banana</option>
          <option>Apple</option>
          <option>Orange</option>
          <option>Mango</option>
        </select>
      </div>
    </div>
  );
}

export default FoodPreferences;