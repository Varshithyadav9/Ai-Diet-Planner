function BasicProfile() {
  return (
    <div className="container">
      <div className="card">
        <h1>Basic Profile</h1>

        <label>Age</label>
        <input type="number" placeholder="Enter age" />

        <label>Gender</label>
        <select>
          <option>Male</option>
          <option>Female</option>
        </select>

        <label>Height (cm)</label>
        <input type="number" placeholder="Height" />

        <label>Weight (kg)</label>
        <input type="number" placeholder="Weight" />

        <label>Activity Level</label>
        <select>
          <option>Sedentary</option>
          <option>Lightly Active</option>
          <option>Moderately Active</option>
          <option>Very Active</option>
        </select>
      </div>
    </div>
  );
}

export default BasicProfile;