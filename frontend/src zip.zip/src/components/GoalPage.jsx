function GoalPage() {
  return (
    <div className="container">
      <div className="card">
        <h1>Body Goal</h1>

        <label>Choose Goal</label>
        <select>
          <option>Fat Loss (Cutting)</option>
          <option>Muscle Gain (Bulking)</option>
          <option>Body Recomposition</option>
          <option>Maintenance</option>
        </select>
      </div>
    </div>
  );
}

export default GoalPage;