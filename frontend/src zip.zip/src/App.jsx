import { useState } from "react";
import "./App.css";

import BasicProfile from "./components/BasicProfile";
import GoalPage from "./components/GoalPage";
import FoodPreferences from "./components/FoodPreferences";
import HabitsPage from "./components/HabitsPage";
import ResultPage from "./components/ResultPage";

function App() {
  const [page, setPage] = useState(1);

  const [data, setData] = useState({
    age: "",
    gender: "",
    height: "",
    weight: "",

    goal: "",
    experience: "",
    targetWeight: "",

    chicken: "",
    eggs: "",
    fish: "",
    milk: "",
    paneer: "",
    rice: "",
    roti: "",
    oats: "",
    whey: "",

    workoutDays: "",
    sleep: "",
    budget: "",
    smoking: "",
    alcohol: ""
  });

  return (
    <div>
      {page === 1 && <BasicProfile data={data} setData={setData} />}
      {page === 2 && <GoalPage data={data} setData={setData} />}
      {page === 3 && <FoodPreferences data={data} setData={setData} />}
      {page === 4 && <HabitsPage data={data} setData={setData} />}
      {page === 5 && <ResultPage data={data} />}

      <div className="bottom-buttons">
        {page > 1 && (
          <button onClick={() => setPage(page - 1)}>
            Back
          </button>
        )}

        {page < 5 && (
          <button onClick={() => setPage(page + 1)}>
            Next
          </button>
        )}
      </div>
    </div>
  );
}

export default App;